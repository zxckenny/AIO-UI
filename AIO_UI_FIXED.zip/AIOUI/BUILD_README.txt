AIO UI - Android APK build

GitHub Actions workflow:
  .github/workflows/build.yml

IMPORTANT:
For GitHub Actions to detect the workflow, extract this archive and upload the
CONTENTS of the AIOUI folder to the ROOT of your GitHub repository. The
.github folder must be directly at repository root, not nested inside AIOUI/.

Then open GitHub -> Actions -> Build AIO UI APK.
On failure, download the AIO-UI-build-diagnostics artifact. It contains the
Gradle build log with the actual error and stack trace.

Project requirements:
  Java 17
  Gradle 8.7
  Android Gradle Plugin 8.5.2
  Kotlin 1.9.24
  Android SDK 34
