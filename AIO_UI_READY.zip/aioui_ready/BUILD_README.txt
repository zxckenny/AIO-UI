AIO UI - Android APK build

1. Extract this ZIP.
2. Upload the CONTENTS of this folder to the ROOT of your GitHub repository.
   The .github folder must be directly in the repository root.
3. Commit and push, or open Actions and run "AIO UI Android APK".
4. On success, download AIO-UI-APK from Artifacts.
5. On failure, download AIO-UI-DIAGNOSTICS and send the ZIP to ChatGPT.

Project settings.gradle.kts is now populated. The workflow also supports an
AIO_UI.zip placed in the repository root, or an already extracted project.
