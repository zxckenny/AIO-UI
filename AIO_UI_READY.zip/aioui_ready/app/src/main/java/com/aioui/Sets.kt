package com.aioui

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import org.json.JSONObject
import java.io.File
import java.util.Calendar

/** Готовый «внешний вид» (то, что получается из ОС-профиля для светлой или тёмной темы). */
class FxSet(
    val id: String, val name: String, val dark: Boolean,
    val bg: Int, val surface: Int, val text: Int, val accent: Int,
    val font: String, val shape: String, val style: String, val widget: String,
    val radius: Int, val dynamic: Boolean,
    val effect: Int, val hue: Int, val mono: Boolean, val colorMode: Int,
    val dock: String = "pill", val cols: Int = 4, val dcols: Int = 4, val iconScale: Int = 100,
    val labels: Boolean = true, val searchBottom: Boolean = false,
    val wallLight: Boolean = false, val glint: Boolean = false, val tag: String = ""
) {
    private fun hex(c: Int) = String.format("#%08X", c)

    fun toJson(): String = JSONObject().apply {
        put("name", name); put("tag", tag); put("dark", dark)
        put("bg", hex(bg)); put("surface", hex(surface)); put("text", hex(text)); put("accent", hex(accent))
        put("font", font)               // sans-serif, sans-serif-light, sans-serif-medium, monospace, serif, casual, custom
        put("iconShape", shape)         // circle, squircle, rounded, square, none
        put("iconStyle", style)         // original, mono, accent, tile
        put("widget", widget)           // dot, ios, md3, neon, aero, min, oneui, stack, pixel
        put("radius", radius); put("dynamic", dynamic)
        put("effect", effect)           // 0..10
        put("hue", hue); put("mono", mono); put("colorMode", colorMode)
        put("dock", dock)               // pill, bar, clear, none
        put("cols", cols); put("dcols", dcols); put("iconScale", iconScale)
        put("labels", labels); put("searchBottom", searchBottom)
        put("wallLight", wallLight); put("glint", glint)
    }.toString(2)
}

/** ОС-профиль: две палитры (тёмная/светлая) + раскладка, иконки, виджеты, обои. */
class Os(
    val id: String, val name: String, val tag: String, val accent: Int,
    val dBg: Int, val dSurf: Int, val dText: Int,
    val lBg: Int, val lSurf: Int, val lText: Int,
    val font: String, val shape: String, val style: String, val widget: String, val radius: Int,
    val dock: String, val cols: Int, val dcols: Int, val iconScale: Int,
    val labels: Boolean, val searchBottom: Boolean,
    val effect: Int, val hue: Int, val mono: Boolean, val colorMode: Int,
    val glint: Boolean, val dynamic: Boolean
) {
    fun toSet(dark: Boolean) = FxSet(
        id, name, dark,
        if (dark) dBg else lBg, if (dark) dSurf else lSurf, if (dark) dText else lText, accent,
        font, shape, style, widget, radius, dynamic,
        effect, hue, mono, colorMode,
        dock, cols, dcols, iconScale, labels, searchBottom, !dark, glint, tag
    )
}

object Sets {
    private fun c(v: Long) = v.toInt()

    val OS: List<Os> = listOf(
        Os(id = "oneui", name = "One UI", tag = "мягкие карточки, 5 колонок", accent = c(0xFF3E91FF),
            dBg = c(0xFF0A0A0A), dSurf = c(0xFF1E1E20), dText = c(0xFFF2F2F2),
            lBg = c(0xFFF4F4F6), lSurf = c(0xFFFFFFFF), lText = c(0xFF121212),
            font = "sans-serif", shape = "squircle", style = "original", widget = "oneui", radius = 30,
            dock = "bar", cols = 5, dcols = 5, iconScale = 92, labels = true, searchBottom = false,
            effect = 10, hue = 215, mono = false, colorMode = 0, glint = false, dynamic = false),
        Os(id = "nothing", name = "Nothing OS", tag = "точки, моно, красный акцент", accent = c(0xFFD71921),
            dBg = c(0xFF000000), dSurf = c(0xFF121212), dText = c(0xFFFFFFFF),
            lBg = c(0xFFF2F2F2), lSurf = c(0xFFFFFFFF), lText = c(0xFF000000),
            font = "monospace", shape = "circle", style = "mono", widget = "dot", radius = 28,
            dock = "clear", cols = 4, dcols = 4, iconScale = 96, labels = true, searchBottom = false,
            effect = 9, hue = 0, mono = true, colorMode = 0, glint = false, dynamic = false),
        Os(id = "ios", name = "iOS", tag = "сквиркл, стеклянные виджеты", accent = c(0xFF0A84FF),
            dBg = c(0xFF000000), dSurf = c(0xFF1C1C1E), dText = c(0xFFFFFFFF),
            lBg = c(0xFFF2F2F7), lSurf = c(0xFFFFFFFF), lText = c(0xFF000000),
            font = "sans-serif", shape = "squircle", style = "original", widget = "ios", radius = 24,
            dock = "pill", cols = 4, dcols = 4, iconScale = 100, labels = true, searchBottom = false,
            effect = 10, hue = 225, mono = false, colorMode = 0, glint = false, dynamic = false),
        Os(id = "pixel", name = "Pixel UI", tag = "Material You, поиск снизу", accent = c(0xFFD0BCFF),
            dBg = c(0xFF1C1B1F), dSurf = c(0xFF2B2930), dText = c(0xFFE6E1E5),
            lBg = c(0xFFFFFBFE), lSurf = c(0xFFF3EDF7), lText = c(0xFF1C1B1F),
            font = "sans-serif-medium", shape = "circle", style = "accent", widget = "pixel", radius = 28,
            dock = "pill", cols = 5, dcols = 5, iconScale = 100, labels = true, searchBottom = true,
            effect = 10, hue = 265, mono = false, colorMode = 4, glint = false, dynamic = true),
        Os(id = "hyperos", name = "HyperOS", tag = "крупные цифры, блобы", accent = c(0xFF3482FF),
            dBg = c(0xFF000000), dSurf = c(0xFF1A1A1C), dText = c(0xFFFFFFFF),
            lBg = c(0xFFF5F5F7), lSurf = c(0xFFFFFFFF), lText = c(0xFF111111),
            font = "sans-serif", shape = "squircle", style = "original", widget = "stack", radius = 32,
            dock = "pill", cols = 4, dcols = 4, iconScale = 102, labels = true, searchBottom = false,
            effect = 10, hue = 255, mono = false, colorMode = 0, glint = false, dynamic = false),
        Os(id = "originos", name = "OriginOS", tag = "жидкое стекло, блики", accent = c(0xFF5B8CFF),
            dBg = c(0xFF0B0D12), dSurf = c(0xFF181B23), dText = c(0xFFF0F2F7),
            lBg = c(0xFFEFF3FA), lSurf = c(0xFFFFFFFF), lText = c(0xFF0E1420),
            font = "sans-serif", shape = "squircle", style = "original", widget = "ios", radius = 30,
            dock = "pill", cols = 4, dcols = 4, iconScale = 100, labels = true, searchBottom = false,
            effect = 10, hue = 195, mono = false, colorMode = 0, glint = true, dynamic = false),
        Os(id = "oxygen", name = "OxygenOS", tag = "красный акцент, чёткие линии", accent = c(0xFFF5010C),
            dBg = c(0xFF000000), dSurf = c(0xFF161616), dText = c(0xFFFFFFFF),
            lBg = c(0xFFF4F4F4), lSurf = c(0xFFFFFFFF), lText = c(0xFF101010),
            font = "sans-serif-medium", shape = "rounded", style = "original", widget = "stack", radius = 24,
            dock = "bar", cols = 5, dcols = 5, iconScale = 96, labels = true, searchBottom = false,
            effect = 10, hue = 355, mono = false, colorMode = 0, glint = false, dynamic = false),
        Os(id = "metro", name = "Windows Phone", tag = "плитки Metro", accent = c(0xFF0078D7),
            dBg = c(0xFF000000), dSurf = c(0xFF1F1F1F), dText = c(0xFFFFFFFF),
            lBg = c(0xFFFFFFFF), lSurf = c(0xFFE6E6E6), lText = c(0xFF000000),
            font = "sans-serif-light", shape = "square", style = "tile", widget = "min", radius = 0,
            dock = "clear", cols = 3, dcols = 3, iconScale = 118, labels = true, searchBottom = false,
            effect = 6, hue = 210, mono = true, colorMode = 0, glint = false, dynamic = false),
        Os(id = "aero", name = "Frutiger Aero", tag = "глянец, пузыри", accent = c(0xFF29B6F6),
            dBg = c(0xFF06243A), dSurf = c(0xFF0B3C5D), dText = c(0xFFE6F6FF),
            lBg = c(0xFFD8F1FF), lSurf = c(0xFFFFFFFF), lText = c(0xFF0B3C5D),
            font = "sans-serif-medium", shape = "circle", style = "original", widget = "aero", radius = 30,
            dock = "pill", cols = 4, dcols = 4, iconScale = 100, labels = true, searchBottom = false,
            effect = 5, hue = 195, mono = false, colorMode = 0, glint = false, dynamic = false)
    )

    /** Секретная ОС (пасхалка: 7 тапов по названию в настройках). */
    val PUDDING: Os = Os(id = "pudding", name = "Pudding OS 🍮", tag = "секретная", accent = c(0xFFFF7EB6),
        dBg = c(0xFF1A0F1F), dSurf = c(0xFF2D1B33), dText = c(0xFFFFE9F5),
        lBg = c(0xFFFFF0F7), lSurf = c(0xFFFFFFFF), lText = c(0xFF3A1B2F),
        font = "casual", shape = "squircle", style = "original", widget = "md3", radius = 36,
        dock = "pill", cols = 4, dcols = 4, iconScale = 100, labels = true, searchBottom = false,
        effect = 7, hue = 330, mono = false, colorMode = 3, glint = true, dynamic = false)

    fun isDark(ctx: Context): Boolean = when (Prefs.sp(ctx).getInt("themeMode", 0)) {
        1 -> false
        2 -> true
        else -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    fun fromJson(id: String, s: String): FxSet? = try {
        val o = JSONObject(s)
        fun col(k: String, d: Int) = try { Color.parseColor(o.optString(k, "")) } catch (e: Exception) { d }
        val dark = o.optBoolean("dark", true)
        FxSet(
            id, o.optString("name", id), dark,
            col("bg", c(0xFF101010)), col("surface", c(0xFF1E1E1E)), col("text", Color.WHITE), col("accent", c(0xFF4FC3F7)),
            o.optString("font", "sans-serif"), o.optString("iconShape", "squircle"),
            o.optString("iconStyle", "original"), o.optString("widget", "md3"),
            o.optInt("radius", 24), o.optBoolean("dynamic", false),
            o.optInt("effect", 10), o.optInt("hue", 210), o.optBoolean("mono", false), o.optInt("colorMode", 0),
            o.optString("dock", "pill"), o.optInt("cols", 4), o.optInt("dcols", 4), o.optInt("iconScale", 100),
            o.optBoolean("labels", true), o.optBoolean("searchBottom", false),
            o.optBoolean("wallLight", !dark), o.optBoolean("glint", false), o.optString("tag", "мой скин")
        )
    } catch (e: Exception) { null }

    private fun dir(ctx: Context) = File(ctx.filesDir, "sets").apply { mkdirs() }

    fun all(ctx: Context): List<FxSet> {
        val d = isDark(ctx)
        val egg = if (Prefs.sp(ctx).getBoolean("egg", false)) listOf(PUDDING.toSet(d)) else emptyList()
        val user = dir(ctx).listFiles()?.filter { it.extension == "json" }?.sortedBy { it.name }
            ?.mapNotNull { fromJson("u_" + it.nameWithoutExtension, it.readText()) } ?: emptyList()
        return OS.map { it.toSet(d) } + egg + user
    }

    fun current(ctx: Context): FxSet {
        val id = Prefs.sp(ctx).getString("setId", "oneui")
        return all(ctx).firstOrNull { it.id == id } ?: OS[0].toSet(isDark(ctx))
    }

    fun apply(ctx: Context, s: FxSet, keep: Boolean = false) {
        val e = Prefs.sp(ctx).edit()
            .putString("setId", s.id)
            .putInt("effect", s.effect).putInt("hue", s.hue)
            .putBoolean("mono", s.mono).putInt("colorMode", s.colorMode)
            .putBoolean("wallLight", s.wallLight).putBoolean("glint", s.glint)
            .putBoolean("showDock", s.dock != "none")
            .putInt("hcols", s.cols).putInt("dcols", s.dcols)
            .putInt("iconSize", s.iconScale).putBoolean("labels", s.labels)
        if (!keep) e.putInt("ovShape", 0).putInt("ovStyle", 0).putInt("ovWidget", 0)
            .putInt("ovFont", 0).putInt("ovRadius", 0).putInt("bgMode", 0)
        e.apply()
    }

    /** После смены темы (светлая/тёмная) подтянуть «светлые обои» под текущую ОС. */
    fun sync(ctx: Context) {
        val sp = Prefs.sp(ctx)
        val s = current(ctx)
        if (sp.getBoolean("wallLight", false) != s.wallLight) sp.edit().putBoolean("wallLight", s.wallLight).apply()
    }

    /** Авто-смена ОС днём / ночью. */
    fun autoApply(ctx: Context) {
        val sp = Prefs.sp(ctx)
        if (!sp.getBoolean("autoSet", false)) return
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val from = sp.getInt("nightFrom", 21)
        val to = sp.getInt("nightTo", 7)
        val night = if (from > to) (h >= from || h < to) else (h >= from && h < to)
        val s = all(ctx).getOrNull(sp.getInt(if (night) "setNightIdx" else "setDayIdx", 0)) ?: return
        if (s.id != sp.getString("setId", "")) apply(ctx, s, true)
    }

    fun importJson(ctx: Context, text: String): FxSet? {
        val tmp = fromJson("tmp", text) ?: return null
        val slug = tmp.name.lowercase().replace(Regex("[^a-z0-9а-я]+"), "_").trim('_').ifEmpty { "set" }
        val id = slug + "_" + (text.hashCode() and 0xffff)
        File(dir(ctx), "$id.json").writeText(text)
        return fromJson("u_$id", text)
    }
}
