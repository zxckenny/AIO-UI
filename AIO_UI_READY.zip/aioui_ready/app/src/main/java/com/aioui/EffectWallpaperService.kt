package com.aioui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Canvas
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.MediaPlayer
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.Choreographer
import android.view.MotionEvent
import android.view.SurfaceHolder
import java.io.File
import kotlin.math.abs
import kotlin.math.sqrt

class EffectWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = FxEngine()

    inner class FxEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val prefs = Prefs.sp(this@EffectWallpaperService)
        private val fx = FxRenderer(this@EffectWallpaperService)
        private var visible = false
        private var lastShake = 0L
        private val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        private val acc: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        private val vib: Vibrator? = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

        private fun vibrate() {
            if (!prefs.getBoolean("wallVib", false)) return
            try {
                if (Build.VERSION.SDK_INT >= 26) vib?.vibrate(VibrationEffect.createOneShot(22L, 90))
                else vib?.vibrate(22L)
            } catch (e: Exception) {}
        }

        // видеообои
        private var mp: MediaPlayer? = null
        private var vReady = false
        private var mpVer = -1L
        private var videoOn = false
        private val vidKeys = setOf("bgMode", "vidVer", "vsound", "vspeed")
        private val plis = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key in vidKeys && visible) applyMode()
        }

        private val choreo = Choreographer.getInstance()
        private var skip = false
        private val frameCb = object : Choreographer.FrameCallback {
            override fun doFrame(frameTimeNanos: Long) {
                if (!visible || videoOn) return
                if (prefs.getBoolean("eco", false)) {
                    skip = !skip
                    if (skip) { choreo.postFrameCallback(this); return }
                }
                frame()
                choreo.postFrameCallback(this)
            }
        }

        private val sl = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val ax = e.values[0]; val ay = e.values[1]; val az = e.values[2]
                val tx = (-ax / 6f).coerceIn(-1f, 1f)
                val ty = ((az - 4f) / 5f).coerceIn(-1f, 1f)
                fx.tiltTargetX = tx
                fx.tiltTargetY = ty
                val mag = sqrt(ax * ax + ay * ay + az * az)
                if (prefs.getBoolean("shake", true) && abs(mag - 9.81f) > 13f) {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastShake > 1800) { lastShake = now; fx.trigger(1) }
                }
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }

        private val rcv = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, i: Intent) {
                when (i.action) {
                    Intent.ACTION_USER_PRESENT -> fx.trigger(prefs.getInt("unlock", 1))
                    Intent.ACTION_SCREEN_ON -> fx.trigger(prefs.getInt("screenOn", 0))
                    Intent.ACTION_SCREEN_OFF -> fx.reset()
                    Intent.ACTION_POWER_CONNECTED -> fx.onPower(true)
                    Intent.ACTION_POWER_DISCONNECTED -> fx.onPower(false)
                    Intent.ACTION_BATTERY_CHANGED -> readBattery(i)
                }
            }
        }

        private fun readBattery(i: Intent?) {
            if (i == null) return
            val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (lvl >= 0 && sc > 0) fx.batteryPct = lvl * 100 / sc
            val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            fx.charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        }

        // ---------- видео ----------

        private fun videoFile() = File(filesDir, "bg.mp4")

        private fun applyMode() {
            choreo.removeFrameCallback(frameCb)
            videoOn = prefs.getInt("bgMode", 0) == 2 && videoFile().exists()
            if (videoOn) {
                if (!surfaceHolder.surface.isValid) return
                val ver = prefs.getLong("vidVer", 0L)
                if (mp == null || ver != mpVer) startVideo(ver)
                else {
                    setVol()
                    try {
                        if (vReady && visible) { if (mp?.isPlaying == false) mp?.start(); applySpeed() }
                    } catch (e: Exception) {}
                }
            } else {
                stopVideo()
                if (visible) choreo.postFrameCallback(frameCb)
            }
        }

        private fun startVideo(ver: Long) {
            stopVideo()
            try {
                val p = MediaPlayer()
                p.setSurface(surfaceHolder.surface)
                p.setDataSource(videoFile().absolutePath)
                p.isLooping = true
                p.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING)
                p.setOnPreparedListener { m ->
                    vReady = true
                    if (visible) { m.start(); applySpeed() }
                }
                p.setOnErrorListener { _, _, _ -> stopVideo(); true }
                mp = p; mpVer = ver; vReady = false
                setVol()
                p.prepareAsync()
            } catch (e: Exception) { stopVideo() }
        }

        private fun stopVideo() {
            vReady = false
            mp?.let { try { it.release() } catch (e: Exception) {} }
            mp = null; mpVer = -1L
        }

        private fun setVol() {
            val v = if (prefs.getBoolean("vsound", false)) 1f else 0f
            try { mp?.setVolume(v, v) } catch (e: Exception) {}
        }

        private fun applySpeed() {
            val p = prefs.getInt("vspeed", 50)
            val sp = if (p <= 50) 0.25f + 0.75f * p / 50f else 1f + (p - 50) / 50f
            try {
                val m = mp ?: return
                if (m.isPlaying) m.playbackParams = m.playbackParams.setSpeed(sp)
            } catch (e: Exception) {}
        }

        // ---------- жизненный цикл ----------

        override fun onCreate(sh: SurfaceHolder) {
            super.onCreate(sh)
            setTouchEventsEnabled(true)
            fx.onFx = { vibrate() }
            prefs.registerOnSharedPreferenceChangeListener(plis)
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_USER_PRESENT)
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_POWER_CONNECTED)
                addAction(Intent.ACTION_POWER_DISCONNECTED)
                addAction(Intent.ACTION_BATTERY_CHANGED)
            }
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(rcv, f, Context.RECEIVER_NOT_EXPORTED)
            else registerReceiver(rcv, f)
            readBattery(registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)))
        }

        override fun onDestroy() {
            visible = false
            choreo.removeFrameCallback(frameCb)
            prefs.unregisterOnSharedPreferenceChangeListener(plis)
            try { unregisterReceiver(rcv) } catch (e: Exception) {}
            sm.unregisterListener(sl)
            stopVideo()
            fx.release()
            super.onDestroy()
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            applyMode()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            choreo.removeFrameCallback(frameCb)
            stopVideo()
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            choreo.removeFrameCallback(frameCb)
            if (v) {
                applyMode()
                acc?.let { sm.registerListener(sl, it, SensorManager.SENSOR_DELAY_GAME) }
            } else {
                sm.unregisterListener(sl)
                try { if (vReady) mp?.pause() } catch (e: Exception) {}
            }
        }

        override fun onOffsetsChanged(xOffset: Float, yOffset: Float, xStep: Float, yStep: Float, xPix: Int, yPix: Int) {
            fx.offsetTarget = xOffset
        }

        override fun onTouchEvent(e: MotionEvent) { fx.onTouch(e) }

        private fun frame() {
            if (videoOn) return
            val holder = surfaceHolder
            var c: Canvas? = null
            try {
                c = if (Build.VERSION.SDK_INT >= 26) {
                    try { holder.lockHardwareCanvas() } catch (e: Exception) { holder.lockCanvas() }
                } else holder.lockCanvas()
                if (c != null) fx.render(c, c.width, c.height)
            } catch (e: Exception) {
            } finally {
                if (c != null) try { holder.unlockCanvasAndPost(c) } catch (e: Exception) {}
            }
        }
    }
}
