package com.aioui

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    val EFFECTS = listOf("Дождь", "Снег", "Звёзды", "Волны", "Матрица", "Пузыри", "Без эффекта", "Светлячки", "Аврора", "Точечная сетка (Nothing)", "Мягкие блобы (One UI / Pixel)")
    val UNLOCK = listOf("Выкл", "Желе", "Ударная волна", "Зум-удар", "Глитч", "Вспышка", "Качели", "Случайный", "Рябь", "Пульс")
    val TOUCH = listOf("Выкл", "Круги", "Искры", "Неоновый след", "Волна от касания")
    val COLOR = listOf("Ручной", "По времени суток", "По заряду батареи", "Радуга", "Системный (Material You)")
    val CLOCK = listOf("Выкл", "Крупные часы", "Мини-часы")
    val THEME = listOf("Авто (как в системе)", "Светлая", "Тёмная")
    val SWIPE_DOWN = listOf("Ничего", "Шторка уведомлений")
    val SORT = listOf("А–Я", "Частые сверху")
    val BG = listOf("Градиент", "Моё фото", "Видео")

    val SHAPE = listOf("Из сета", "Круг", "Сквиркл", "Скруглённый квадрат", "Квадрат", "Без формы")
    val SHAPE_KEYS = listOf("", "circle", "squircle", "rounded", "square", "none")
    val ISTYLE = listOf("Из сета", "Оригинал", "Моно", "Акцент (как Material You)", "Плитка (Metro)")
    val ISTYLE_KEYS = listOf("", "original", "mono", "accent", "tile")
    val WSTYLE = listOf("Из сета", "Nothing (точки)", "iOS (стекло)", "Material You", "Неон", "Aero", "Минимал", "One UI (карточка)", "Стопка (HyperOS)", "Pixel (без фона)")
    val WSTYLE_KEYS = listOf("", "dot", "ios", "md3", "neon", "aero", "min", "oneui", "stack", "pixel")
    val FONT = listOf("Из сета", "Системный", "Моно", "Serif", "Light", "Condensed", "Свой (.ttf)")
    val FONT_KEYS = listOf("", "sans-serif", "monospace", "serif", "sans-serif-light", "sans-serif-condensed", "custom")
    val LAUNCH_ANIM = listOf("Масштаб", "Затухание", "Без анимации")
    val DRAWER_ANIM = listOf("Выезд снизу", "Масштаб + затухание", "Затухание")

    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
}
