package com.aioui

import android.app.Activity
import android.content.Context
import android.graphics.*
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import java.io.File
import kotlin.math.max

/** Область Wiggle: закрашиваешь пальцем то, что должно колыхаться. */
class MaskView(ctx: Context) : View(ctx) {
    private val prefs = Prefs.sp(ctx)
    private var mask: Bitmap? = null
    private var mc: Canvas? = null
    private var photo: Bitmap? = null
    private val bgPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val overlay = Paint(Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = PorterDuffColorFilter(0x99FF4081L.toInt(), PorterDuff.Mode.SRC_IN)
    }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val mat = Matrix()
    private val dst = RectF()
    var erase = false
    var brush = 0.08f
    private var lx = 0f
    private var ly = 0f

    init {
        val f = File(ctx.filesDir, "bg.jpg")
        if (prefs.getInt("bgMode", 0) == 1 && f.exists()) {
            photo = try { BitmapFactory.decodeFile(f.absolutePath) } catch (e: Throwable) { null }
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w <= 0 || h <= 0) return
        val mw = 108
        val mh = max(1, (mw * h.toFloat() / w).toInt())
        val m = Bitmap.createBitmap(mw, mh, Bitmap.Config.ARGB_8888)
        val c = Canvas(m)
        val f = File(context.filesDir, "wiggle.png")
        if (f.exists()) {
            try {
                val old = BitmapFactory.decodeFile(f.absolutePath)
                if (old != null) {
                    c.drawBitmap(old, null, RectF(0f, 0f, mw.toFloat(), mh.toFloat()), null)
                    old.recycle()
                }
            } catch (e: Throwable) {}
        }
        mask = m
        mc = c
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val p = photo
        if (p != null) {
            val s = max(w / p.width, h / p.height) * 1.15f
            mat.reset()
            mat.postScale(s, s)
            mat.postTranslate((w - p.width * s) / 2f, (h - p.height * s) / 2f)
            c.drawBitmap(p, mat, bgPaint)
            c.drawColor(0x33000000)
        } else {
            bgPaint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF10131A.toInt(), 0xFF2A3550.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, bgPaint)
            bgPaint.shader = null
        }
        val m = mask ?: return
        dst.set(0f, 0f, w, h)
        c.drawBitmap(m, null, dst, overlay)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val m = mask ?: return false
        val c = mc ?: return false
        val x = e.x * m.width / width
        val y = e.y * m.height / height
        stroke.strokeWidth = brush * m.width
        stroke.maskFilter = BlurMaskFilter(max(1f, stroke.strokeWidth * 0.35f), BlurMaskFilter.Blur.NORMAL)
        stroke.xfermode = if (erase) PorterDuffXfermode(PorterDuff.Mode.CLEAR) else null
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lx = x; ly = y; c.drawPoint(x, y, stroke) }
            MotionEvent.ACTION_MOVE -> { c.drawLine(lx, ly, x, y, stroke); lx = x; ly = y }
        }
        invalidate()
        return true
    }

    fun clear() { mask?.eraseColor(Color.TRANSPARENT); invalidate() }

    fun save() {
        val m = mask ?: return
        try {
            File(context.filesDir, "wiggle.png").outputStream().use { m.compress(Bitmap.CompressFormat.PNG, 100, it) }
            prefs.edit().putLong("wigVer", System.currentTimeMillis()).apply()
        } catch (e: Throwable) {}
    }
}

class WiggleActivity : Activity() {
    private lateinit var mv: MaskView
    private lateinit var pv: PreviewView
    private var testing = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sp = Prefs.sp(this)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        val pad = (12 * resources.displayMetrics.density).toInt()
        val root = FrameLayout(this)
        mv = MaskView(this)
        pv = PreviewView(this)
        pv.visibility = View.GONE
        root.addView(mv, FrameLayout.LayoutParams(-1, -1))
        root.addView(pv, FrameLayout.LayoutParams(-1, -1))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC000000.toInt())
            setPadding(pad, pad, pad, pad * 2)
        }
        panel.addView(TextView(this).apply {
            text = "Закрась то, что должно колыхаться (персонаж, цветок…)"
            setTextColor(Color.WHITE)
            textSize = 13f
        })
        fun btn(t: String, onClick: () -> Unit): Button {
            val bt = Button(this)
            bt.text = t
            bt.setOnClickListener { onClick() }
            return bt
        }
        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        row1.addView(btn("Кисть") { mv.erase = false }, LinearLayout.LayoutParams(0, -2, 1f))
        row1.addView(btn("Ластик") { mv.erase = true }, LinearLayout.LayoutParams(0, -2, 1f))
        row1.addView(btn("Очистить") { mv.clear() }, LinearLayout.LayoutParams(0, -2, 1f))
        panel.addView(row1)
        panel.addView(TextView(this).apply { text = "Размер кисти"; setTextColor(Color.WHITE) })
        val seek = SeekBar(this)
        seek.max = 22
        seek.progress = 6
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { mv.brush = (p + 2) / 100f }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        panel.addView(seek)

        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        val test = Button(this)
        test.text = "▶ Проверить"
        test.setOnClickListener {
            testing = !testing
            if (testing) {
                mv.save()
                sp.edit().putBoolean("wigOn", true).apply()
                mv.visibility = View.GONE
                pv.visibility = View.VISIBLE
                test.text = "✎ Править"
                pv.fx.wiggle()
            } else {
                pv.visibility = View.GONE
                mv.visibility = View.VISIBLE
                test.text = "▶ Проверить"
            }
        }
        row2.addView(test, LinearLayout.LayoutParams(0, -2, 1f))
        row2.addView(btn("Готово") {
            mv.save()
            sp.edit().putBoolean("wigOn", true).apply()
            finish()
        }, LinearLayout.LayoutParams(0, -2, 1f))
        panel.addView(row2)
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
    }

    override fun onPause() {
        if (::mv.isInitialized) mv.save()
        super.onPause()
    }
}
