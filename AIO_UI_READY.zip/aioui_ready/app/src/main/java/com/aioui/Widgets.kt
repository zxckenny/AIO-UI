package com.aioui

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.*
import android.os.BatteryManager
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Базовая карточка виджета: фон зависит от стиля сета. */
abstract class CardView(ctx: Context, protected val look: Look, private val hDp: Int) : View(ctx) {
    protected val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val tick = object : Runnable {
        override fun run() { invalidate(); postDelayed(this, 1000) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(tick) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }
    override fun onMeasure(ws: Int, hs: Int) { setMeasuredDimension(MeasureSpec.getSize(ws), look.dp(hDp)) }

    protected fun tc(): Int = when (look.widget) {
        "ios", "min", "pixel" -> if (look.pal.dark) Color.WHITE else look.pal.text
        "aero" -> 0xFF0B3C5D.toInt()
        else -> look.pal.text
    }

    private fun stroke(c: Canvas, r: Float, color: Int, wDp: Float) {
        p.style = Paint.Style.STROKE; p.strokeWidth = look.dp(wDp).toFloat(); p.color = color
        c.drawRoundRect(rect, r, r, p)
        p.style = Paint.Style.FILL
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = look.dp(look.radiusDp).toFloat()
        rect.set(0f, 0f, w, h)
        p.shader = null; p.style = Paint.Style.FILL; p.clearShadowLayer()
        when (look.widget) {
            "dot" -> { p.color = if (look.pal.dark) Color.BLACK else Color.WHITE; c.drawRoundRect(rect, r, r, p); stroke(c, r, if (look.pal.dark) 0x33FFFFFF else 0x33000000, 1f) }
            "ios" -> { p.color = if (look.pal.dark) 0x59FFFFFF else 0xB3FFFFFFL.toInt(); c.drawRoundRect(rect, r, r, p); stroke(c, r, 0x80FFFFFFL.toInt(), 1.5f) }
            "oneui" -> { p.color = look.pal.surface; c.drawRoundRect(rect, r, r, p) }
            "stack" -> { p.color = (look.pal.surface and 0x00FFFFFF) or 0xD9000000L.toInt(); c.drawRoundRect(rect, r, r, p) }
            "md3" -> { p.color = look.pal.surface; c.drawRoundRect(rect, r, r, p) }
            "neon" -> { p.color = 0xCC000000L.toInt(); c.drawRoundRect(rect, r, r, p); stroke(c, r, look.pal.accent, 2f) }
            "aero" -> {
                p.shader = LinearGradient(0f, 0f, 0f, h, 0xE6FFFFFFL.toInt(), 0xCCB3E5FCL.toInt(), Shader.TileMode.CLAMP)
                c.drawRoundRect(rect, r, r, p)
                p.shader = null; p.color = 0x55FFFFFF
                c.drawRoundRect(RectF(w * 0.03f, h * 0.03f, w * 0.97f, h * 0.5f), r * 0.8f, r * 0.8f, p)
                stroke(c, r, Color.WHITE, 2f)
            }
            else -> {}
        }
        p.style = Paint.Style.FILL; p.shader = null
        content(c, w, h)
    }

    protected fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align, tf: Typeface = look.font) {
        p.typeface = tf; p.textSize = size; p.color = color; p.textAlign = align
        c.drawText(s, x, y, p)
    }

    abstract fun content(c: Canvas, w: Float, h: Float)
}

class ClockWidget(ctx: Context, look: Look) :
    CardView(ctx, look, if (look.widget == "dot") 190 else if (look.widget == "min" || look.widget == "pixel") 120 else 160) {

    private val tf = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val df = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault())

    private val glyphs: Map<Char, Array<String>> = mapOf(
        '0' to arrayOf("01110", "10001", "10011", "10101", "11001", "10001", "01110"),
        '1' to arrayOf("00100", "01100", "00100", "00100", "00100", "00100", "01110"),
        '2' to arrayOf("01110", "10001", "00001", "00010", "00100", "01000", "11111"),
        '3' to arrayOf("11110", "00001", "00001", "01110", "00001", "00001", "11110"),
        '4' to arrayOf("00010", "00110", "01010", "10010", "11111", "00010", "00010"),
        '5' to arrayOf("11111", "10000", "11110", "00001", "00001", "10001", "01110"),
        '6' to arrayOf("00110", "01000", "10000", "11110", "10001", "10001", "01110"),
        '7' to arrayOf("11111", "00001", "00010", "00100", "01000", "01000", "01000"),
        '8' to arrayOf("01110", "10001", "10001", "01110", "10001", "10001", "01110"),
        '9' to arrayOf("01110", "10001", "10001", "01111", "00001", "00010", "01100"),
        ':' to arrayOf("0", "0", "1", "0", "1", "0", "0")
    )

    override fun content(c: Canvas, w: Float, h: Float) {
        val now = Date()
        val time = tf.format(now)
        val date = df.format(now)
        val pad = look.dp(18).toFloat()
        when (look.widget) {
            "dot" -> {
                val cols = 25
                val cell = min((w - 2 * pad) / cols, (h - 2 * pad - h * 0.16f) / 7f)
                var x = (w - cols * cell) / 2f
                for (ch in time) {
                    val g = glyphs[ch] ?: continue
                    val gw = g[0].length
                    for (r in 0 until 7) for (k in 0 until gw) {
                        p.color = if (g[r][k] == '1') (if (ch == ':') look.pal.accent else (if (look.pal.dark) Color.WHITE else Color.BLACK)) else (if (look.pal.dark) 0x22FFFFFF else 0x22000000)
                        c.drawCircle(x + k * cell + cell / 2f, pad + r * cell + cell / 2f, cell * 0.36f, p)
                    }
                    x += (gw + 1) * cell
                }
                text(c, date.uppercase(), w / 2f, h - pad * 0.8f, h * 0.1f, look.pal.accent, Paint.Align.CENTER, Typeface.MONOSPACE)
            }
            "ios" -> {
                text(c, date, pad, pad + h * 0.12f, h * 0.12f, (tc() and 0x00FFFFFF) or 0xD9000000L.toInt(), Paint.Align.LEFT)
                text(c, time, pad, h - pad, h * 0.46f, tc(), Paint.Align.LEFT)
            }
            "oneui" -> {
                text(c, time, pad, h * 0.6f, h * 0.44f, look.pal.text, Paint.Align.LEFT)
                text(c, date, pad, h * 0.84f, h * 0.11f, (look.pal.text and 0x00FFFFFF) or 0xB3000000L.toInt(), Paint.Align.LEFT)
                p.color = look.pal.accent
                c.drawCircle(w - pad - h * 0.07f, pad + h * 0.07f, h * 0.07f, p)
            }
            "stack" -> {
                val bold = Typeface.create(look.font, Typeface.BOLD)
                text(c, time.substring(0, 2), pad, h * 0.5f, h * 0.44f, look.pal.text, Paint.Align.LEFT, bold)
                text(c, time.substring(3, 5), pad, h * 0.94f, h * 0.44f, look.pal.accent, Paint.Align.LEFT, bold)
                text(c, date, w - pad, h * 0.2f, h * 0.1f, (look.pal.text and 0x00FFFFFF) or 0xB3000000L.toInt(), Paint.Align.RIGHT)
            }
            "pixel" -> {
                p.setShadowLayer(10f, 0f, 2f, if (look.pal.dark) 0x66000000 else 0x00000000)
                text(c, date, pad / 2f, h * 0.22f, h * 0.15f, tc(), Paint.Align.LEFT)
                text(c, time, pad / 2f, h * 0.88f, h * 0.62f, tc(), Paint.Align.LEFT, Typeface.create("sans-serif-thin", Typeface.NORMAL))
                p.clearShadowLayer()
            }
            "md3" -> {
                p.color = (look.pal.accent and 0x00FFFFFF) or 0x40000000
                c.drawCircle(w * 0.9f, h * 0.18f, h * 0.55f, p)
                text(c, time, pad, h * 0.58f, h * 0.38f, look.pal.text, Paint.Align.LEFT)
                p.textSize = h * 0.11f; p.typeface = look.font
                val tw = p.measureText(date)
                p.color = look.pal.accent
                c.drawRoundRect(RectF(pad, h * 0.68f, pad + tw + pad, h * 0.68f + h * 0.2f), h, h, p)
                text(c, date, pad + pad / 2f, h * 0.68f + h * 0.14f, h * 0.11f, look.pal.bg, Paint.Align.LEFT)
            }
            "neon" -> {
                p.setShadowLayer(24f, 0f, 0f, look.pal.accent)
                text(c, time, w / 2f, h * 0.6f, h * 0.38f, look.pal.accent, Paint.Align.CENTER)
                p.clearShadowLayer()
                text(c, date, w / 2f, h * 0.82f, h * 0.1f, look.pal.text, Paint.Align.CENTER)
            }
            "aero" -> {
                p.setShadowLayer(8f, 0f, 3f, 0x88FFFFFFL.toInt())
                text(c, time, w / 2f, h * 0.6f, h * 0.4f, tc(), Paint.Align.CENTER)
                p.clearShadowLayer()
                text(c, date, w / 2f, h * 0.82f, h * 0.1f, 0xFF29B6F6L.toInt(), Paint.Align.CENTER)
            }
            else -> { // min
                p.setShadowLayer(8f, 0f, 2f, 0xAA000000L.toInt())
                text(c, time, pad / 2f, h * 0.6f, h * 0.42f, tc(), Paint.Align.LEFT)
                text(c, date, pad / 2f, h * 0.85f, h * 0.13f, (tc() and 0x00FFFFFF) or 0xCC000000L.toInt(), Paint.Align.LEFT)
                p.clearShadowLayer()
            }
        }
    }
}

class BatteryWidget(ctx: Context, look: Look) : CardView(ctx, look, 120) {
    private val oval = RectF()

    override fun content(c: Canvas, w: Float, h: Float) {
        val i: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = lvl * 100 / max(1, sc)
        val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val cx = h / 2f
        val cy = h / 2f
        val r = h * 0.32f
        val active = if (chg) 0xFF4CAF50L.toInt() else look.pal.accent
        if (look.widget == "dot") {
            for (k in 0 until 36) {
                val a = Math.toRadians(k * 10.0 - 90.0)
                p.color = if (k < pct * 36 / 100) active else 0x33FFFFFF
                c.drawCircle(cx + (r * cos(a)).toFloat(), cy + (r * sin(a)).toFloat(), h * 0.035f, p)
            }
        } else {
            oval.set(cx - r, cy - r, cx + r, cy + r)
            p.style = Paint.Style.STROKE; p.strokeWidth = h * 0.09f; p.strokeCap = Paint.Cap.ROUND
            p.color = (tc() and 0x00FFFFFF) or 0x33000000
            c.drawArc(oval, -90f, 360f, false, p)
            p.color = active
            c.drawArc(oval, -90f, 360f * pct / 100f, false, p)
            p.style = Paint.Style.FILL
        }
        text(c, "$pct%", cx, cy + h * 0.07f, h * 0.2f, tc(), Paint.Align.CENTER)
        text(c, "Батарея", h + look.dp(8), h * 0.46f, h * 0.17f, tc(), Paint.Align.LEFT)
        text(c, if (chg) "Заряжается" else "Не заряжается", h + look.dp(8), h * 0.66f, h * 0.12f,
            (tc() and 0x00FFFFFF) or 0xB0000000L.toInt(), Paint.Align.LEFT)
    }
}
