package com.aioui

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.*
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

/** Мини-превью рабочего стола выбранной ОС: обои, виджет, иконки, док. */
class OsCard(ctx: Context) : View(ctx) {
    var set: FxSet? = null
    var selected = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    private val palette = intArrayOf(
        0xFF34C759.toInt(), 0xFF0A84FF.toInt(), 0xFFFF9F0A.toInt(), 0xFFFF375F.toInt(),
        0xFF5E5CE6.toInt(), 0xFF64D2FF.toInt(), 0xFFFFD60A.toInt()
    )

    override fun onMeasure(ws: Int, hs: Int) {
        val w = MeasureSpec.getSize(ws)
        setMeasuredDimension(w, (w * 1.75f).toInt())
    }

    private fun hsv(h: Float, s: Float, v: Float) =
        Color.HSVToColor(255, floatArrayOf(((h % 360f) + 360f) % 360f, s, v))

    private fun shapeRect(c: Canvas, shape: String, l: Float, t: Float, s: Float) {
        rf.set(l, t, l + s, t + s)
        when (shape) {
            "circle" -> c.drawOval(rf, p)
            "squircle" -> c.drawRoundRect(rf, s * 0.32f, s * 0.32f, p)
            "rounded" -> c.drawRoundRect(rf, s * 0.22f, s * 0.22f, p)
            else -> c.drawRoundRect(rf, s * 0.05f, s * 0.05f, p)
        }
    }

    private fun iconColor(s: FxSet, base: Int): Int = when (s.style) {
        "mono" -> if (s.dark) 0xFF2A2A2E.toInt() else 0xFFDADADF.toInt()
        "tile" -> s.accent
        "accent" -> s.surface
        else -> base
    }

    private fun glyphColor(s: FxSet): Int = when (s.style) {
        "mono" -> if (s.dark) Color.WHITE else Color.BLACK
        "accent" -> s.accent
        else -> 0xDDFFFFFF.toInt()
    }

    override fun onDraw(c: Canvas) {
        val s = set ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        val tint = if (s.mono) 0f else 1f

        // корпус телефона
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = if (selected) s.accent else 0xFF3A3A40.toInt()
        rf.set(0f, 0f, w, h)
        c.drawRoundRect(rf, w * 0.11f, w * 0.11f, p)

        // экран с обоями ОС
        val m = w * 0.04f
        rf.set(m, m, w - m, h - m)
        val rr = w * 0.085f
        p.shader = if (s.wallLight)
            LinearGradient(0f, 0f, w, h, hsv(s.hue.toFloat(), 0.10f * tint, 0.98f),
                hsv(s.hue + 30f, 0.24f * tint, 0.88f), Shader.TileMode.CLAMP)
        else
            LinearGradient(0f, 0f, w, h, hsv(s.hue.toFloat(), 0.50f * tint, 0.22f),
                hsv(s.hue + 40f, 0.60f * tint, 0.42f), Shader.TileMode.CLAMP)
        c.drawRoundRect(rf, rr, rr, p)
        p.shader = null

        // виджет часов
        val x0 = m * 2.2f
        val wx = w - m * 4.4f
        val wy = h * 0.09f
        val wh = h * 0.15f
        rf.set(x0, wy, x0 + wx, wy + wh)
        val cr = if (s.radius == 0) 0f else wh * 0.28f
        when (s.widget) {
            "min", "pixel" -> {}
            "dot" -> { p.color = if (s.dark) Color.BLACK else Color.WHITE; c.drawRoundRect(rf, cr, cr, p) }
            "ios", "aero" -> { p.color = if (s.dark) 0x55FFFFFF else 0xAAFFFFFF.toInt(); c.drawRoundRect(rf, cr, cr, p) }
            else -> { p.color = s.surface; c.drawRoundRect(rf, cr, cr, p) }
        }
        p.typeface = Typeface.create(if (s.font == "custom") "sans-serif" else s.font, Typeface.NORMAL)
        p.textAlign = Paint.Align.LEFT
        p.textSize = wh * 0.62f
        p.color = s.text
        c.drawText("9:41", x0 + wh * 0.25f, wy + wh * 0.72f, p)
        p.color = s.accent
        c.drawCircle(x0 + wx - wh * 0.22f, wy + wh * 0.22f, wh * 0.08f, p)

        // сетка иконок
        val cols = s.cols.coerceIn(3, 5)
        val cell = wx / cols
        val sz = cell * 0.62f * (s.iconScale / 100f)
        val top = h * 0.30f
        val rowH = cell * 1.08f
        var k = 0
        for (r in 0 until 3) {
            for (cc in 0 until cols) {
                val cx = x0 + cell * (cc + 0.5f)
                val cy = top + rowH * r
                p.color = iconColor(s, palette[k % palette.size])
                shapeRect(c, s.shape, cx - sz / 2f, cy, sz)
                p.color = glyphColor(s)
                c.drawCircle(cx, cy + sz / 2f, sz * 0.2f, p)
                k++
            }
        }

        // док
        val dh = h * 0.085f
        val dy = h - m - h * 0.115f
        val dp = m * (if (s.dock == "bar") 1.2f else 2.0f)
        rf.set(dp, dy, w - dp, dy + dh)
        if (s.dock != "clear") {
            p.color = (s.surface and 0x00FFFFFF) or 0xCC000000.toInt()
            c.drawRoundRect(rf, dh * 0.45f, dh * 0.45f, p)
        }
        for (i in 0 until 4) {
            val cx = dp + (w - 2 * dp) * (i + 0.5f) / 4f
            p.color = iconColor(s, palette[(i + 2) % palette.size])
            shapeRect(c, s.shape, cx - dh * 0.34f, dy + dh * 0.16f, dh * 0.68f)
        }
    }
}

/** Выбор ОС: карточки с живым превью, светлая/тёмная тема, кнопка «Применить». */
class OsPickerActivity : Activity() {
    private lateinit var sp: SharedPreferences
    private lateinit var grid: LinearLayout
    private lateinit var themeRow: LinearLayout
    private lateinit var applyBtn: Button
    private val cards = ArrayList<OsCard>()
    private var selId = "oneui"
    private var pad = 0

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = Prefs.sp(this)
        selId = sp.getString("setId", "oneui") ?: "oneui"
        pad = (14 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF0E0F13.toInt())
        root.setPadding(pad, pad * 2, pad, pad)

        val title = TextView(this)
        title.text = "Выбери свою ОС"
        title.textSize = 26f
        title.setTextColor(Color.WHITE)
        title.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        root.addView(title)

        val sub = TextView(this)
        sub.text = "AIO UI превратит телефон в выбранную систему: иконки, шрифт, виджеты, док, обои."
        sub.textSize = 13f
        sub.setTextColor(0xFFA0A4B0.toInt())
        sub.setPadding(0, pad / 3, 0, pad / 2)
        root.addView(sub)

        themeRow = LinearLayout(this)
        themeRow.orientation = LinearLayout.HORIZONTAL
        root.addView(themeRow)

        val scroll = ScrollView(this)
        grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        applyBtn = Button(this)
        applyBtn.setOnClickListener { applySel() }
        root.addView(applyBtn, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
        rebuild()
    }

    private fun rebuild() {
        themeRow.removeAllViews()
        val mode = sp.getInt("themeMode", 0)
        Prefs.THEME.forEachIndexed { i, n ->
            val bt = Button(this)
            bt.text = (if (i == mode) "● " else "") + n
            bt.textSize = 12f
            bt.setOnClickListener { sp.edit().putInt("themeMode", i).apply(); rebuild() }
            themeRow.addView(bt, LinearLayout.LayoutParams(0, -2, 1f))
        }

        grid.removeAllViews()
        cards.clear()
        val sets = Sets.all(this)
        if (sets.none { it.id == selId }) selId = sets[0].id
        for (row in sets.chunked(2)) {
            val rl = LinearLayout(this)
            rl.orientation = LinearLayout.HORIZONTAL
            for (s in row) {
                val col = LinearLayout(this)
                col.orientation = LinearLayout.VERTICAL
                col.gravity = Gravity.CENTER_HORIZONTAL
                col.setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
                val card = OsCard(this)
                card.set = s
                card.selected = s.id == selId
                card.setOnClickListener {
                    selId = s.id
                    for (cd in cards) { cd.selected = cd.set?.id == selId; cd.invalidate() }
                    updateBtn()
                }
                cards.add(card)
                col.addView(card, LinearLayout.LayoutParams(-1, -2))
                val nm = TextView(this)
                nm.text = s.name
                nm.textSize = 15f
                nm.setTextColor(Color.WHITE)
                nm.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                nm.setPadding(0, pad / 3, 0, 0)
                col.addView(nm)
                val tg = TextView(this)
                tg.text = s.tag
                tg.textSize = 11f
                tg.setTextColor(0xFF8D91A0.toInt())
                col.addView(tg)
                rl.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            }
            if (row.size == 1) rl.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            grid.addView(rl)
        }
        updateBtn()
    }

    private fun updateBtn() {
        val name = Sets.all(this).firstOrNull { it.id == selId }?.name ?: ""
        applyBtn.text = "Применить: $name"
    }

    private fun applySel() {
        val s = Sets.all(this).firstOrNull { it.id == selId } ?: return
        Sets.apply(this, s)
        sp.edit().putBoolean("osChosen", true).putBoolean("osAsked", true).apply()
        AlertDialog.Builder(this)
            .setTitle("ОС «" + s.name + "» применена")
            .setMessage("Чтобы увидеть её на рабочем столе, сделай AIO UI лаунчером по умолчанию.")
            .setPositiveButton("Открыть настройки") { _, _ ->
                try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
                catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
                finish()
            }
            .setNegativeButton("Позже") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }
}
