package com.aioui

import android.content.Context
import android.graphics.Canvas
import android.view.MotionEvent
import android.view.View

class PreviewView(ctx: Context) : View(ctx) {
    val fx = FxRenderer(ctx)
    var touchEnabled = true

    override fun onDraw(c: Canvas) {
        c.clipRect(0, 0, width, height)
        fx.render(c, width, height)
        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!touchEnabled) return false
        if (e.actionMasked == MotionEvent.ACTION_DOWN) parent?.requestDisallowInterceptTouchEvent(true)
        fx.onTouch(e)
        return true
    }

    override fun onWindowVisibilityChanged(v: Int) {
        super.onWindowVisibilityChanged(v)
        if (v == VISIBLE) postInvalidateOnAnimation()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        fx.release()
    }
}
